<?php
// SIMPLE SOLUTION - Form Submit Fix + Phone Conversion

// Add JavaScript to fix form
function simple_phone_fix() {
    ?>
    <script>
    // Run immediately
    (function() {
        const numMap = {
            '٠':'0','١':'1','٢':'2','٣':'3','٤':'4','٥':'5','٦':'6','٧':'7','٨':'8','٩':'9',
            '۰':'0','۱':'1','۲':'2','۳':'3','۴':'4','۵':'5','۶':'6','۷':'7','۸':'8','۹':'9',
            '०':'0','१':'1','२':'2','३':'3','४':'4','५':'5','६':'6','७':'7','८':'8','९':'9',
            '০':'0','১':'1','২':'2','৩':'3','৪':'4','৫':'5','৬':'6','৭':'7','৮':'8','৯':'9'
        };

        function convertPhone(val) {
            if (!val) return val;
            val = val.replace(/\s/g, '');
            let result = '';
            for (let char of val) {
                result += numMap[char] || char;
            }
            return result.replace(/[^0-9+\-]/g, '');
        }

        function fixAllForms() {
            // Fix all forms on page
            document.querySelectorAll('form').forEach(function(form) {
                // Remove novalidate if present (it causes issues)
                form.removeAttribute('novalidate');

                // Find all phone fields in this form
                form.querySelectorAll('input[type="tel"], input[name*="phone" i], input[name*="Phone" i], input[id*="phone" i]').forEach(function(input) {
                    // Remove pattern - MAIN FIX
                    input.removeAttribute('pattern');
                    input.removeAttribute('aria-invalid');

                    // Convert on input
                    input.addEventListener('input', function() {
                        this.value = convertPhone(this.value);
                    });
                });
            });
        }

        // Run on load
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', fixAllForms);
        } else {
            fixAllForms();
        }

        // Run after any AJAX
        document.addEventListener('wpcf7mailsent', fixAllForms);
        document.addEventListener('wpcf7invalid', fixAllForms);
        document.addEventListener('wpcf7submit', fixAllForms);
    })();
    </script>
    <?php
}
add_action('wp_footer', 'simple_phone_fix', 999);

// Convert phone on backend
function simple_convert_backend() {
    if (!empty($_POST)) {
        foreach ($_POST as $key => $value) {
            if (stripos($key, 'phone') !== false || stripos($key, 'tel') !== false) {
                if (!is_array($value)) {
                    // Remove spaces
                    $value = str_replace(' ', '', $value);
                    // Convert numbers
                    $map = array(
                        '٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4',
                        '٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9',
                        '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4',
                        '۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',
                        '०'=>'0','१'=>'1','२'=>'2','३'=>'3','४'=>'4',
                        '५'=>'5','६'=>'6','७'=>'7','८'=>'8','९'=>'9',
                        '০'=>'0','১'=>'1','২'=>'2','৩'=>'3','৪'=>'4',
                        '৫'=>'5','৬'=>'6','৭'=>'7','৮'=>'8','৯'=>'9'
                    );
                    $value = strtr($value, $map);
                    $value = preg_replace('/[^0-9+\-]/', '', $value);
                    $_POST[$key] = $value;
                }
            }
        }
    }
}
add_action('init', 'simple_convert_backend', 1);

// Fix Contact Form 7
function fix_cf7_submit($result, $tag) {
    $name = $tag['name'];
    if (isset($_POST[$name]) && (strpos($tag['type'], 'tel') !== false || stripos($name, 'phone') !== false)) {
        $value = $_POST[$name];
        $value = str_replace(' ', '', $value);
        $map = array(
            '٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4',
            '٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9',
            '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4',
            '۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',
            '०'=>'0','१'=>'1','२'=>'2','३'=>'3','४'=>'4',
            '५'=>'5','६'=>'6','७'=>'7','८'=>'8','९'=>'9',
            '০'=>'0','১'=>'1','২'=>'2','৩'=>'3','৪'=>'4',
            '৫'=>'5','৬'=>'6','৭'=>'7','৮'=>'8','৯'=>'9'
        );
        $value = strtr($value, $map);
        $value = preg_replace('/[^0-9+\-]/', '', $value);
        $_POST[$name] = $value;
    }
    return $result;
}
add_filter('wpcf7_validate_tel', 'fix_cf7_submit', 999, 2);
add_filter('wpcf7_validate_tel*', 'fix_cf7_submit', 999, 2);
?>