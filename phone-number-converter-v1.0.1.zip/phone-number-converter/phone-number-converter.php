<?php
/**
 * Plugin Name: Phone Number Auto-Converter
 * Plugin URI:  https://example.com/phone-number-converter
 * Description: Automatically converts phone numbers from any language/script (Arabic, Urdu, Persian, Hindi, etc.) to English digits. Prevents spacing mistakes in phone fields.
 * Version:     1.0.1
 * Author:      Your Name
 * License:     GPL-2.0+
 * Text Domain: phone-number-converter
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'PNC_VERSION',     '1.0.1' );
define( 'PNC_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'PNC_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );

require_once PNC_PLUGIN_DIR . 'includes/class-pnc-converter.php';
require_once PNC_PLUGIN_DIR . 'includes/class-pnc-hooks.php';
require_once PNC_PLUGIN_DIR . 'admin/class-pnc-admin.php';

function pnc_init() {
    $hooks = new PNC_Hooks();
    $hooks->register();

    if ( is_admin() ) {
        $admin = new PNC_Admin();
        $admin->register();
    }
}
add_action( 'plugins_loaded', 'pnc_init' );

register_activation_hook( __FILE__, 'pnc_activate' );
function pnc_activate() {
    $defaults = array(
        'apply_to_comments'    => 1,
        'apply_to_woocommerce' => 1,
        'apply_to_cf7'         => 1,
        'apply_to_gravity'     => 1,
        'apply_to_all_inputs'  => 1,
        'strip_spaces'         => 1,
        'strip_dashes'         => 0,
        'allowed_chars'        => '+',
    );
    add_option( 'pnc_settings', $defaults );
}

register_deactivation_hook( __FILE__, 'pnc_deactivate' );
function pnc_deactivate() {
    // nothing needed
}
