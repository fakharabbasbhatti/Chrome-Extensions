<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * PNC_Hooks
 *
 * Registers all WordPress hooks for phone number conversion.
 *
 * Changelog v1.0.1:
 * - FIX: Changed sanitize_post_data() hook priority from 1 to 999 to prevent
 *   interference with Contact Form 7's nonce/security field verification,
 *   which was causing "submission failed because of a server error".
 * - FIX: sanitize_post_data() now skips CF7 internal fields (_wpcf7_* keys)
 *   to avoid any accidental modification of security tokens.
 */
class PNC_Hooks {

    private $settings;

    public function __construct() {
        $this->settings = get_option( 'pnc_settings', array() );
    }

    public function register() {
        // ── Front-end JS (live input conversion) ──────────────────────────
        add_action( 'wp_enqueue_scripts',    array( $this, 'enqueue_scripts' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

        // ── Comment form ──────────────────────────────────────────────────
        if ( ! empty( $this->settings['apply_to_comments'] ) ) {
            add_filter( 'pre_comment_author_url', array( $this, 'maybe_convert' ) );
            add_filter( 'comment_post', array( $this, 'sanitize_comment_phone' ), 10, 2 );
        }

        // ── WooCommerce checkout / my-account ─────────────────────────────
        if ( ! empty( $this->settings['apply_to_woocommerce'] ) ) {
            add_filter( 'woocommerce_checkout_posted_data',     array( $this, 'sanitize_wc_checkout' ) );
            add_filter( 'woocommerce_process_myaccount_field_billing_phone', array( $this, 'maybe_convert' ) );
            add_action( 'woocommerce_checkout_update_order_meta', array( $this, 'sanitize_wc_order_meta' ) );
        }

        // ── Contact Form 7 ────────────────────────────────────────────────
        if ( ! empty( $this->settings['apply_to_cf7'] ) ) {
            add_filter( 'wpcf7_posted_data', array( $this, 'sanitize_cf7_data' ) );
        }

        // ── Gravity Forms ─────────────────────────────────────────────────
        if ( ! empty( $this->settings['apply_to_gravity'] ) ) {
            add_filter( 'gform_field_value',      array( $this, 'sanitize_gravity_field' ), 10, 3 );
            add_filter( 'gform_save_field_value',  array( $this, 'sanitize_gravity_save' ),  10, 5 );
        }

        // ── Generic $_POST sanitizer (catches everything else) ────────────
        // Priority 999: run LATE so CF7, nonce checks, and security verifications
        // have already completed before we touch $_POST.
        if ( ! empty( $this->settings['apply_to_all_inputs'] ) ) {
            add_action( 'init', array( $this, 'sanitize_post_data' ), 999 );
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // Scripts
    // ─────────────────────────────────────────────────────────────────────

    public function enqueue_scripts() {
        wp_enqueue_script(
            'pnc-converter',
            PNC_PLUGIN_URL . 'assets/js/pnc-converter.js',
            array(),
            PNC_VERSION,
            true
        );
        wp_localize_script( 'pnc-converter', 'pncSettings', array(
            'stripSpaces'  => ! empty( $this->settings['strip_spaces'] ),
            'stripDashes'  => ! empty( $this->settings['strip_dashes'] ),
            'allowedChars' => isset( $this->settings['allowed_chars'] ) ? $this->settings['allowed_chars'] : '+',
        ) );
    }

    // ─────────────────────────────────────────────────────────────────────
    // Helpers
    // ─────────────────────────────────────────────────────────────────────

    public function maybe_convert( $value ) {
        return PNC_Converter::convert( $value, $this->settings );
    }

    private function is_phone_key( $key ) {
        return (bool) preg_match( '/phone|tel|mobile|cell|fax/i', $key );
    }

    /**
     * Returns true for CF7 internal security/meta keys that must never be touched.
     */
    private function is_protected_key( $key ) {
        return (bool) preg_match( '/^_wpcf7|^_wpnonce|^nonce|^action$/i', $key );
    }

    // ─────────────────────────────────────────────────────────────────────
    // Per-integration sanitizers
    // ─────────────────────────────────────────────────────────────────────

    /**
     * Generic $_POST sanitizer.
     * Runs at priority 999 (late) so CF7 and other plugins validate their
     * security tokens first. Also skips any protected/nonce keys.
     */
    public function sanitize_post_data() {
        if ( empty( $_POST ) ) return;
        foreach ( $_POST as $key => $value ) {
            if ( $this->is_protected_key( $key ) ) {
                continue; // never touch security/nonce fields
            }
            if ( $this->is_phone_key( $key ) && is_string( $value ) ) {
                $_POST[ $key ] = PNC_Converter::convert( $value, $this->settings );
            }
        }
    }

    public function sanitize_comment_phone( $comment_id, $approved ) {
        if ( isset( $_POST['comment_phone'] ) ) {
            update_comment_meta(
                $comment_id,
                'comment_phone',
                PNC_Converter::convert( sanitize_text_field( $_POST['comment_phone'] ), $this->settings )
            );
        }
    }

    public function sanitize_wc_checkout( $data ) {
        foreach ( $data as $key => $value ) {
            if ( $this->is_phone_key( $key ) && is_string( $value ) ) {
                $data[ $key ] = PNC_Converter::convert( $value, $this->settings );
            }
        }
        return $data;
    }

    public function sanitize_wc_order_meta( $order_id ) {
        $phone = get_post_meta( $order_id, '_billing_phone', true );
        if ( $phone ) {
            update_post_meta( $order_id, '_billing_phone', PNC_Converter::convert( $phone, $this->settings ) );
        }
    }

    public function sanitize_cf7_data( $data ) {
        foreach ( $data as $key => $value ) {
            if ( $this->is_phone_key( $key ) && is_string( $value ) ) {
                $data[ $key ] = PNC_Converter::convert( $value, $this->settings );
            }
        }
        return $data;
    }

    public function sanitize_gravity_field( $value, $field, $name ) {
        if ( $field->type === 'phone' ) {
            return PNC_Converter::convert( $value, $this->settings );
        }
        return $value;
    }

    public function sanitize_gravity_save( $value, $lead, $field, $form, $input_id ) {
        if ( $field->type === 'phone' ) {
            return PNC_Converter::convert( $value, $this->settings );
        }
        return $value;
    }
}
