<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * PNC_Converter
 *
 * Converts phone-number strings from any Unicode numeral script to ASCII 0-9.
 * Also strips illegal characters (spaces inside the number, letters, etc.)
 * while preserving an optional leading '+' for international format.
 */
class PNC_Converter {

    /**
     * Map every Unicode numeral to its ASCII equivalent.
     * Covers: Arabic-Indic, Extended Arabic-Indic (Persian/Urdu),
     * Devanagari (Hindi/Marathi/Nepali), Bengali, Gurmukhi, Gujarati,
     * Oriya, Tamil, Telugu, Kannada, Malayalam, Thai, Lao, Tibetan,
     * Myanmar, Khmer, Mongolian, Limbu, New Tai Lue, Buginese,
     * Tai Tham, Balinese, Sundanese, Lepcha, Ol Chiki, Vai, Saurashtra,
     * Kayah Li, Javanese, Cham, Meetei Mayek, fullwidth digits, and more.
     */
    private static $digit_map = array(
        // Arabic-Indic  ٠١٢٣٤٥٦٧٨٩
        "\xD9\xA0"=>'0',"\xD9\xA1"=>'1',"\xD9\xA2"=>'2',"\xD9\xA3"=>'3',
        "\xD9\xA4"=>'4',"\xD9\xA5"=>'5',"\xD9\xA6"=>'6',"\xD9\xA7"=>'7',
        "\xD9\xA8"=>'8',"\xD9\xA9"=>'9',
        // Extended Arabic-Indic (Perso-Arabic / Urdu)  ۰۱۲۳۴۵۶۷۸۹
        "\xDB\xB0"=>'0',"\xDB\xB1"=>'1',"\xDB\xB2"=>'2',"\xDB\xB3"=>'3',
        "\xDB\xB4"=>'4',"\xDB\xB5"=>'5',"\xDB\xB6"=>'6',"\xDB\xB7"=>'7',
        "\xDB\xB8"=>'8',"\xDB\xB9"=>'9',
        // Devanagari  ०१२३४५६७८९
        "\xE0\xA5\xA6"=>'0',"\xE0\xA5\xA7"=>'1',"\xE0\xA5\xA8"=>'2',"\xE0\xA5\xA9"=>'3',
        "\xE0\xA5\xAA"=>'4',"\xE0\xA5\xAB"=>'5',"\xE0\xA5\xAC"=>'6',"\xE0\xA5\xAD"=>'7',
        "\xE0\xA5\xAE"=>'8',"\xE0\xA5\xAF"=>'9',
        // Bengali  ০১২৩৪৫৬৭৮৯
        "\xE0\xA7\xA6"=>'0',"\xE0\xA7\xA7"=>'1',"\xE0\xA7\xA8"=>'2',"\xE0\xA7\xA9"=>'3',
        "\xE0\xA7\xAA"=>'4',"\xE0\xA7\xAB"=>'5',"\xE0\xA7\xAC"=>'6',"\xE0\xA7\xAD"=>'7',
        "\xE0\xA7\xAE"=>'8',"\xE0\xA7\xAF"=>'9',
        // Gurmukhi  ੦੧੨੩੪੫੬੭੮੯
        "\xE0\xA9\xA6"=>'0',"\xE0\xA9\xA7"=>'1',"\xE0\xA9\xA8"=>'2',"\xE0\xA9\xA9"=>'3',
        "\xE0\xA9\xAA"=>'4',"\xE0\xA9\xAB"=>'5',"\xE0\xA9\xAC"=>'6',"\xE0\xA9\xAD"=>'7',
        "\xE0\xA9\xAE"=>'8',"\xE0\xA9\xAF"=>'9',
        // Gujarati  ૦૧૨૩૪૫૬૭૮૯
        "\xE0\xAB\xA6"=>'0',"\xE0\xAB\xA7"=>'1',"\xE0\xAB\xA8"=>'2',"\xE0\xAB\xA9"=>'3',
        "\xE0\xAB\xAA"=>'4',"\xE0\xAB\xAB"=>'5',"\xE0\xAB\xAC"=>'6',"\xE0\xAB\xAD"=>'7',
        "\xE0\xAB\xAE"=>'8',"\xE0\xAB\xAF"=>'9',
        // Oriya  ୦୧୨୩୪୫୬୭୮୯
        "\xE0\xAD\xA6"=>'0',"\xE0\xAD\xA7"=>'1',"\xE0\xAD\xA8"=>'2',"\xE0\xAD\xA9"=>'3',
        "\xE0\xAD\xAA"=>'4',"\xE0\xAD\xAB"=>'5',"\xE0\xAD\xAC"=>'6',"\xE0\xAD\xAD"=>'7',
        "\xE0\xAD\xAE"=>'8',"\xE0\xAD\xAF"=>'9',
        // Tamil  ௦௧௨௩௪௫௬௭௮௯
        "\xE0\xAF\xA6"=>'0',"\xE0\xAF\xA7"=>'1',"\xE0\xAF\xA8"=>'2',"\xE0\xAF\xA9"=>'3',
        "\xE0\xAF\xAA"=>'4',"\xE0\xAF\xAB"=>'5',"\xE0\xAF\xAC"=>'6',"\xE0\xAF\xAD"=>'7',
        "\xE0\xAF\xAE"=>'8',"\xE0\xAF\xAF"=>'9',
        // Telugu  ౦౧౨౩౪౫౬౭౮౯
        "\xE0\xB1\xA6"=>'0',"\xE0\xB1\xA7"=>'1',"\xE0\xB1\xA8"=>'2',"\xE0\xB1\xA9"=>'3',
        "\xE0\xB1\xAA"=>'4',"\xE0\xB1\xAB"=>'5',"\xE0\xB1\xAC"=>'6',"\xE0\xB1\xAD"=>'7',
        "\xE0\xB1\xAE"=>'8',"\xE0\xB1\xAF"=>'9',
        // Kannada  ೦೧೨೩೪೫೬೭೮೯
        "\xE0\xB3\xA6"=>'0',"\xE0\xB3\xA7"=>'1',"\xE0\xB3\xA8"=>'2',"\xE0\xB3\xA9"=>'3',
        "\xE0\xB3\xAA"=>'4',"\xE0\xB3\xAB"=>'5',"\xE0\xB3\xAC"=>'6',"\xE0\xB3\xAD"=>'7',
        "\xE0\xB3\xAE"=>'8',"\xE0\xB3\xAF"=>'9',
        // Malayalam  ൦൧൨൩൪൫൬൭൮൯
        "\xE0\xB5\xA6"=>'0',"\xE0\xB5\xA7"=>'1',"\xE0\xB5\xA8"=>'2',"\xE0\xB5\xA9"=>'3',
        "\xE0\xB5\xAA"=>'4',"\xE0\xB5\xAB"=>'5',"\xE0\xB5\xAC"=>'6',"\xE0\xB5\xAD"=>'7',
        "\xE0\xB5\xAE"=>'8',"\xE0\xB5\xAF"=>'9',
        // Thai  ๐๑๒๓๔๕๖๗๘๙
        "\xE0\xB9\x90"=>'0',"\xE0\xB9\x91"=>'1',"\xE0\xB9\x92"=>'2',"\xE0\xB9\x93"=>'3',
        "\xE0\xB9\x94"=>'4',"\xE0\xB9\x95"=>'5',"\xE0\xB9\x96"=>'6',"\xE0\xB9\x97"=>'7',
        "\xE0\xB9\x98"=>'8',"\xE0\xB9\x99"=>'9',
        // Myanmar  ၀၁၂၃၄၅၆၇၈၉
        "\xE1\x81\x80"=>'0',"\xE1\x81\x81"=>'1',"\xE1\x81\x82"=>'2',"\xE1\x81\x83"=>'3',
        "\xE1\x81\x84"=>'4',"\xE1\x81\x85"=>'5',"\xE1\x81\x86"=>'6',"\xE1\x81\x87"=>'7',
        "\xE1\x81\x88"=>'8',"\xE1\x81\x89"=>'9',
        // Khmer  ០១២៣៤៥៦៧៨៩
        "\xE1\x9F\xA0"=>'0',"\xE1\x9F\xA1"=>'1',"\xE1\x9F\xA2"=>'2',"\xE1\x9F\xA3"=>'3',
        "\xE1\x9F\xA4"=>'4',"\xE1\x9F\xA5"=>'5',"\xE1\x9F\xA6"=>'6',"\xE1\x9F\xA7"=>'7',
        "\xE1\x9F\xA8"=>'8',"\xE1\x9F\xA9"=>'9',
        // Fullwidth digits  ０１２３４５６７８９
        "\xEF\xBC\x90"=>'0',"\xEF\xBC\x91"=>'1',"\xEF\xBC\x92"=>'2',"\xEF\xBC\x93"=>'3',
        "\xEF\xBC\x94"=>'4',"\xEF\xBC\x95"=>'5',"\xEF\xBC\x96"=>'6',"\xEF\xBC\x97"=>'7',
        "\xEF\xBC\x98"=>'8',"\xEF\xBC\x99"=>'9',
    );

    /**
     * Convert all non-ASCII digits in a phone string to ASCII,
     * strip spaces (and optionally dashes), keep leading '+'.
     *
     * @param  string $phone     Raw phone input.
     * @param  array  $settings  Plugin settings array.
     * @return string
     */
    public static function convert( $phone, $settings = array() ) {
        if ( empty( $phone ) || ! is_string( $phone ) ) {
            return $phone;
        }

        $defaults = array(
            'strip_spaces' => true,
            'strip_dashes' => false,
            'allowed_chars' => '+',
        );
        $settings = wp_parse_args( $settings, $defaults );

        // 1. Replace all Unicode digits with ASCII equivalents
        $phone = strtr( $phone, self::$digit_map );

        // 2. Strip internal spaces (always — this is the core mistake prevention)
        if ( $settings['strip_spaces'] ) {
            $phone = preg_replace( '/\s+/', '', $phone );
        }

        // 3. Optionally strip dashes
        if ( $settings['strip_dashes'] ) {
            $phone = str_replace( '-', '', $phone );
        }

        // 4. Build the allowed character class
        $allowed = '0-9';
        if ( ! empty( $settings['allowed_chars'] ) ) {
            $allowed .= preg_quote( $settings['allowed_chars'], '/' );
        }

        // 5. Remove everything that isn't in the allowed set
        //    but preserve a leading '+' for international numbers
        $leading_plus = ( substr( $phone, 0, 1 ) === '+' ) ? '+' : '';
        $phone        = preg_replace( '/[^' . $allowed . ']/', '', $phone );

        // Re-ensure leading plus didn't get stripped when allowed_chars includes it
        if ( $leading_plus && substr( $phone, 0, 1 ) !== '+' ) {
            $phone = '+' . $phone;
        }

        return $phone;
    }

    /**
     * Quick check: does this string contain any non-ASCII Unicode digits?
     */
    public static function has_non_ascii_digits( $string ) {
        return (bool) preg_match( '/[\xD9\xDB\xE0\xE1\xEF]/', $string );
    }
}
