/**
 * Phone Number Auto-Converter — front-end script
 * Converts non-ASCII digits to English in real time as the user types.
 */
(function () {
    'use strict';

    // ── Unicode digit tables ──────────────────────────────────────────────
    var digitRanges = [
        [0x0660, 0x0669],  // Arabic-Indic
        [0x06F0, 0x06F9],  // Extended Arabic-Indic (Urdu/Persian)
        [0x0966, 0x096F],  // Devanagari (Hindi)
        [0x09E6, 0x09EF],  // Bengali
        [0x0A66, 0x0A6F],  // Gurmukhi
        [0x0AE6, 0x0AEF],  // Gujarati
        [0x0B66, 0x0B6F],  // Oriya
        [0x0BE6, 0x0BEF],  // Tamil
        [0x0C66, 0x0C6F],  // Telugu
        [0x0CE6, 0x0CEF],  // Kannada
        [0x0D66, 0x0D6F],  // Malayalam
        [0x0E50, 0x0E59],  // Thai
        [0x0ED0, 0x0ED9],  // Lao
        [0x0F20, 0x0F29],  // Tibetan
        [0x1040, 0x1049],  // Myanmar
        [0x17E0, 0x17E9],  // Khmer
        [0xFF10, 0xFF19],  // Fullwidth
    ];

    function convertDigits(str) {
        return str.replace(/./gu, function (ch) {
            var cp = ch.codePointAt(0);
            for (var i = 0; i < digitRanges.length; i++) {
                if (cp >= digitRanges[i][0] && cp <= digitRanges[i][1]) {
                    return String(cp - digitRanges[i][0]);
                }
            }
            return ch;
        });
    }

    var settings = window.pncSettings || { stripSpaces: true, stripDashes: false, allowedChars: '+' };

    function cleanPhone(value) {
        // 1. Convert non-ASCII digits
        var result = convertDigits(value);

        // 2. Strip internal spaces
        if (settings.stripSpaces) {
            result = result.replace(/\s+/g, '');
        }

        // 3. Strip dashes
        if (settings.stripDashes) {
            result = result.replace(/-/g, '');
        }

        // 4. Keep only allowed characters
        var allowed = '0-9' + (settings.allowedChars || '').replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&');
        var re = new RegExp('[^' + allowed + ']', 'g');
        var hasLeadingPlus = result.charAt(0) === '+';
        result = result.replace(re, '');
        // Re-prepend '+' if it was stripped but should be kept
        if (hasLeadingPlus && result.charAt(0) !== '+' && (settings.allowedChars || '').indexOf('+') !== -1) {
            result = '+' + result;
        }

        return result;
    }

    // ── Selectors that identify phone inputs ──────────────────────────────
    var PHONE_SELECTORS = [
        'input[type="tel"]',
        'input[name*="phone"]',
        'input[name*="mobile"]',
        'input[name*="cell"]',
        'input[name*="fax"]',
        'input[id*="phone"]',
        'input[id*="mobile"]',
        'input[class*="phone"]',
        '#pnc_demo_input',               // admin demo
    ].join(',');

    function attachToInput(input) {
        if (input._pncAttached) return;
        input._pncAttached = true;

        function handleInput() {
            var pos = input.selectionStart;
            var original = input.value;
            var cleaned  = cleanPhone(original);
            if (cleaned !== original) {
                input.value = cleaned;
                // Try to restore caret position
                var newPos = Math.min(pos, cleaned.length);
                try { input.setSelectionRange(newPos, newPos); } catch (e) {}
            }
            // Update admin demo output
            if (input.id === 'pnc_demo_input') {
                var out = document.getElementById('pnc_demo_output');
                if (out) out.textContent = cleaned || '—';
            }
        }

        input.addEventListener('input',  handleInput);
        input.addEventListener('paste',  function () { setTimeout(handleInput, 0); });
        input.addEventListener('change', handleInput);
        input.addEventListener('blur',   handleInput);
    }

    function attachToAll() {
        var inputs = document.querySelectorAll(PHONE_SELECTORS);
        inputs.forEach(attachToInput);
    }

    // ── Init ──────────────────────────────────────────────────────────────
    document.addEventListener('DOMContentLoaded', attachToAll);

    // Watch for dynamically added inputs (AJAX forms, WooCommerce steps, etc.)
    if (window.MutationObserver) {
        var observer = new MutationObserver(function (mutations) {
            mutations.forEach(function (m) {
                m.addedNodes.forEach(function (node) {
                    if (node.nodeType !== 1) return;
                    if (node.matches && node.matches(PHONE_SELECTORS)) {
                        attachToInput(node);
                    }
                    var children = node.querySelectorAll ? node.querySelectorAll(PHONE_SELECTORS) : [];
                    children.forEach(attachToInput);
                });
            });
        });
        observer.observe(document.body, { childList: true, subtree: true });
    }

})();
