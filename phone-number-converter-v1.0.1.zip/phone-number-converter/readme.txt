=== Phone Number Auto-Converter ===
Contributors: yourname
Tags: phone, number, arabic, urdu, hindi, converter, woocommerce, contact form 7
Requires at least: 5.0
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.0.1
License: GPLv2 or later

Converts phone numbers from any language script to English digits. Prevents spacing mistakes in phone fields.

== Description ==

**Phone Number Auto-Converter** solves two common problems:

1. **Non-English digits** — Users type phone numbers in Arabic (٠١٢٣), Urdu/Persian (۰۱۲۳), Hindi (०१२३), Bengali, Thai, and many other scripts. This plugin converts all of them to standard English (ASCII) digits automatically.

2. **Spacing mistakes** — Users accidentally insert spaces inside a phone number (e.g. `0321 123 4567`). The plugin strips those spaces on both the client and server side.

**Supported scripts (20+):**
Arabic-Indic, Extended Arabic-Indic (Urdu/Persian), Devanagari (Hindi/Marathi/Nepali), Bengali, Gurmukhi, Gujarati, Oriya, Tamil, Telugu, Kannada, Malayalam, Thai, Lao, Tibetan, Myanmar, Khmer, Mongolian, Fullwidth digits, and more.

**Works with:**
* All standard `<input type="tel">` and phone-named inputs
* WooCommerce checkout & My Account
* Contact Form 7
* Gravity Forms
* Any custom form (generic $_POST hook)
* Dynamically injected forms (AJAX / multi-step)

== Installation ==

1. Upload the `phone-number-converter` folder to `/wp-content/plugins/`.
2. Activate from **Plugins → Installed Plugins**.
3. Configure at **Settings → Phone Converter**.

== Changelog ==

= 1.0.1 =
* FIX: Contact Form 7 forms now submit correctly. The generic $_POST sanitizer
  hook was running at priority 1 (too early), interfering with CF7's internal
  nonce/security verification and causing "submission failed because of a server
  error". Hook priority changed to 999 so CF7 security checks complete first.
* FIX: Added protection for WordPress nonce and CF7 internal keys (_wpcf7_*)
  so they are never modified by the generic sanitizer.

= 1.0.0 =
* Initial release.
