<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class PNC_Admin {

    public function register() {
        add_action( 'admin_menu', array( $this, 'add_menu' ) );
        add_action( 'admin_init', array( $this, 'register_settings' ) );
        add_action( 'admin_notices', array( $this, 'maybe_show_notice' ) );
    }

    public function add_menu() {
        add_options_page(
            __( 'Phone Number Converter', 'phone-number-converter' ),
            __( 'Phone Converter', 'phone-number-converter' ),
            'manage_options',
            'pnc-settings',
            array( $this, 'render_page' )
        );
    }

    public function register_settings() {
        register_setting( 'pnc_settings_group', 'pnc_settings', array( $this, 'sanitize_settings' ) );
    }

    public function sanitize_settings( $input ) {
        $clean = array();
        $checkboxes = array( 'apply_to_comments', 'apply_to_woocommerce', 'apply_to_cf7',
                             'apply_to_gravity', 'apply_to_all_inputs', 'strip_spaces', 'strip_dashes' );
        foreach ( $checkboxes as $key ) {
            $clean[ $key ] = isset( $input[ $key ] ) ? 1 : 0;
        }
        $clean['allowed_chars'] = sanitize_text_field( $input['allowed_chars'] ?? '+' );
        return $clean;
    }

    public function maybe_show_notice() {
        if ( isset( $_GET['page'] ) && $_GET['page'] === 'pnc-settings' && isset( $_GET['settings-updated'] ) ) {
            echo '<div class="notice notice-success is-dismissible"><p>' .
                 esc_html__( 'Settings saved.', 'phone-number-converter' ) . '</p></div>';
        }
    }

    public function render_page() {
        $settings = get_option( 'pnc_settings', array() );
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Phone Number Auto-Converter', 'phone-number-converter' ); ?></h1>
            <p><?php esc_html_e( 'Automatically converts phone numbers from Arabic, Urdu, Hindi, Persian, Bengali, Thai and 15+ other scripts to English digits. Also prevents spacing mistakes inside phone fields.', 'phone-number-converter' ); ?></p>

            <form method="post" action="options.php">
                <?php settings_fields( 'pnc_settings_group' ); ?>

                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><?php esc_html_e( 'Apply to', 'phone-number-converter' ); ?></th>
                        <td>
                            <?php $this->checkbox( $settings, 'apply_to_all_inputs',  __( 'All phone/tel/mobile fields (recommended)', 'phone-number-converter' ) ); ?>
                            <?php $this->checkbox( $settings, 'apply_to_woocommerce', __( 'WooCommerce checkout', 'phone-number-converter' ) ); ?>
                            <?php $this->checkbox( $settings, 'apply_to_cf7',         __( 'Contact Form 7', 'phone-number-converter' ) ); ?>
                            <?php $this->checkbox( $settings, 'apply_to_gravity',     __( 'Gravity Forms', 'phone-number-converter' ) ); ?>
                            <?php $this->checkbox( $settings, 'apply_to_comments',    __( 'Comment forms', 'phone-number-converter' ) ); ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e( 'Clean-up rules', 'phone-number-converter' ); ?></th>
                        <td>
                            <?php $this->checkbox( $settings, 'strip_spaces', __( 'Strip spaces inside the number (e.g. "03 21" → "0321")', 'phone-number-converter' ) ); ?>
                            <?php $this->checkbox( $settings, 'strip_dashes', __( 'Strip dashes (e.g. "0321-123" → "0321123")', 'phone-number-converter' ) ); ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="pnc_allowed_chars"><?php esc_html_e( 'Extra allowed characters', 'phone-number-converter' ); ?></label>
                        </th>
                        <td>
                            <input type="text" id="pnc_allowed_chars" name="pnc_settings[allowed_chars]"
                                   value="<?php echo esc_attr( $settings['allowed_chars'] ?? '+' ); ?>"
                                   class="regular-text" />
                            <p class="description"><?php esc_html_e( 'Characters to keep besides 0–9. Default: + (for international codes like +92). Leave blank to allow digits only.', 'phone-number-converter' ); ?></p>
                        </td>
                    </tr>
                </table>

                <h2><?php esc_html_e( 'Live Demo', 'phone-number-converter' ); ?></h2>
                <p><?php esc_html_e( 'Type or paste a phone number in any language below to see the conversion in real time.', 'phone-number-converter' ); ?></p>
                <input type="text" id="pnc_demo_input" placeholder="e.g. ٠٣٢١ ۱۲۳۴۵۶۷" class="regular-text" style="font-size:1.2em;" />
                <p><?php esc_html_e( 'Converted:', 'phone-number-converter' ); ?> <strong id="pnc_demo_output" style="font-size:1.2em;color:#0073aa;">—</strong></p>

                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    private function checkbox( $settings, $key, $label ) {
        $checked = ! empty( $settings[ $key ] ) ? 'checked' : '';
        echo '<label><input type="checkbox" name="pnc_settings[' . esc_attr( $key ) . ']" value="1" ' . $checked . '> '
             . esc_html( $label ) . '</label><br>';
    }
}
